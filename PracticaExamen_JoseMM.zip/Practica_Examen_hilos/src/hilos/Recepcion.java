package hilos;

import java.util.Random;

import main.Main;

public class Recepcion implements Runnable{
	
	static Random rnd = new Random();
	int contador = 0;
	public Recepcion() {
	}
	
	@Override
	public void run() {
	    int aGenerar = rnd.nextInt(20 - 10 + 1) + 10;
	    try {
	        while (contador < aGenerar) {
	            int gravedad = rnd.nextInt(10 - 1 + 1) + 1;
	            //int tiempoAtencion = rnd.nextInt(10000 - 5000 + 1) + 5000; 
	            
	            contador++;
	            Paciente paciente = new Paciente(("Paciente" + contador), gravedad, 1000);
	            
	            Main.lista.put(paciente);
	            System.out.println("RECEPCIÓN: Ha entrado " + paciente.getNombre() + " con gravedad " + gravedad);
	            Thread.sleep(1000); 
	        }
	    } catch (InterruptedException e) {
	        e.printStackTrace();
	    }

	    System.out.println("RECEPCIÓN CERRADA: Se han asignado " + contador + " pacientes hoy.");
	}

}
