package hilos;

import main.Main;

public class Medico implements Runnable {

	String nombre;
	
	public Medico(String nombre) {
		this.nombre = nombre;
	}

	@Override
	public void run() {
	    try {
	        while (Main.lista.size() != 0) {
	            Paciente paciente = Main.lista.take();
	            System.out.println("Médico " + nombre + " comienza a atender a " + paciente.getNombre());
	            
	            paciente.run();
	            
	            System.out.println("Médico " + nombre + " ha terminado con " + paciente.getNombre()+"\n\n");
	            System.out.println("------------------------");
	        }
	    } catch (InterruptedException e) {
	        return;
	    }
	}
	

}
