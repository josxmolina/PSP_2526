package hilos;

public class Paciente implements Runnable, Comparable<Paciente>{

	static int contador = 0;
	int id;
	String nombre;
	int gravedad;
	int tiempoAtencion;
	
	
	public Paciente(String nombre, int gravedad, int tiempoAtencion) {
		this.id = ++contador;
		this.nombre = nombre;
		this.gravedad = gravedad;
		this.tiempoAtencion = tiempoAtencion;
	}

	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public int getGravedad() {
		return gravedad;
	}


	public void setGravedad(int gravedad) {
		this.gravedad = gravedad;
	}


	public int getTiempoAtencion() {
		return tiempoAtencion;
	}


	public void setTiempoAtencion(int tiempoAtencion) {
		this.tiempoAtencion = tiempoAtencion;
	}


	@Override
	public int compareTo(Paciente o) {
		
		//En orden descendente
		int comparacion = Integer.compare(o.gravedad, this.gravedad);
		
		if(comparacion!=0) {
			return comparacion;
		}
		
		//Orden ascendente
		return Integer.compare(this.id ,o.id);
	}

	@Override
	public void run() {
		try {
			System.out.println("El paciente "+nombre+"con gravedad "+gravedad+" esta siendo atendido...\n");
			Thread.sleep(tiempoAtencion);
			System.out.println("El paciente "+nombre+" ya ha sido atendido...\n");
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}

	
	
}
