package main;

import java.util.concurrent.PriorityBlockingQueue;

import hilos.Medico;
import hilos.Paciente;
import hilos.Recepcion;

public class Main {

	public static PriorityBlockingQueue<Paciente> lista =  new PriorityBlockingQueue<>();
	public static void main(String[] args) throws InterruptedException {
		
		System.out.println("Comienza el gran dia en el hospital\n");
		Thread hiloRecepcion = new Thread(new Recepcion());
		hiloRecepcion.run();
		System.out.println("Los pacientes estan llegando al hospital.. \n");
		hiloRecepcion.join();
		System.out.println("Ya han llegado los pacientes, el medico empieza a trabajar\n");
		Thread hiloMedico = new Thread(new Medico("Paco"));
		hiloMedico.run();
		hiloMedico.join();
		System.out.println("Dia finalizado\n");
	}

}
